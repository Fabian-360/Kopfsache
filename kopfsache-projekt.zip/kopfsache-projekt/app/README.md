# Kopfsache

Fabians persönliche Lern-App (Multiple Choice, Lernen / Test / Übungsheft, Kartenstapel, Münzen).
Läuft offline als Web-App auf dem iPad. Der Stoff steht in `content.json`.
